"""
IntelliSense integration for Lakehouse Plumber.

This module provides functionality for setting up VS Code IntelliSense
support for Lakehouse Plumber YAML files.
"""

__version__ = "0.1.0" 